﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class FormEntrusted : Form
    {
        public FormEntrusted()
        {
            InitializeComponent();
        }

        int readerId = 0;
        int bookId = 0;


        private void FormEntrusted_Load(object sender, EventArgs e)
        {

            readersLoad();
            booksLoad();
        }

        void getBookProfile()
        {
            lblRegistrationNumber.Text = "";
            lblBookName.Text = "";
            lblAuthor.Text = "";

            foreach (DataRow row in IDataBase.DataToDataTable("select * from books where aktif = 1 and id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = bookId }).Rows)
            {
                lblRegistrationNumber.Text = row["registrationnumber"].ToString();
                lblBookName.Text = row["bookname"].ToString();
                lblAuthor.Text = row["author"].ToString();
            }
        }

        void getReaderProfile()
        {
            lblNameSurname.Text = "";
            lblClass.Text = "";
            lblSchoolNumber.Text = "";
            lblPriceofDelay.Text = "";


            foreach (DataRow row in IDataBase.DataToDataTable("select * from readers where aktif = 1 and id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = readerId }).Rows)
            {

                lblNameSurname.Text = row["name"].ToString() + " " + row["surname"].ToString();
                lblClass.Text = row["class"].ToString();
                lblSchoolNumber.Text = row["schoolnumber"].ToString();
                lblPriceofDelay.Text = "No";



            }

            bookId = getEntrustId();
            getBookProfile();
        }





        void readersLoad()
        {
            dgReader.DataSource = IDataBase.DataToDataTable(
                "select * from readers where aktif = 1 and name+' '+surname like @search",
                    new SqlParameter("@search", SqlDbType.VarChar) { Value = string.Format("%{0}%", txtFilterReader.Text) });
        }

        void booksLoad()
        {
            dgBook.DataSource = IDataBase.DataToDataTable(
                "select * from books where aktif = 1 and bookname like @search",
                    new SqlParameter("@search", SqlDbType.VarChar) { Value = string.Format("%{0}%", txtFilterBook.Text) });
        }


        void Entrust()
        {
            if (bookId == 0 || readerId == 0)
            {
                MessageBox.Show("You did not choose a book or a reader!");
                return;
            }

            if (getEntrustId() > 0)
            {
                MessageBox.Show("The selected reader has escrow!");
                return;
            }


            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@bookId", SqlDbType.Int) { Value = bookId });
            parameters.Add(new SqlParameter("@readerId", SqlDbType.Int) { Value = readerId });
            parameters.Add(new SqlParameter("@entrustedDate", SqlDbType.Date) { Value = DateTime.Now });
            parameters.Add(new SqlParameter("@undo", SqlDbType.Date) { Value = DateTime.Now.AddDays(30) });

            IDataBase.executeNonQuery(
                "update books set durum = 0 where id = @bookId " +
                "insert into entrusted (bookId, readerId,entrustedDate, undo) values (@bookId, @readerId, @entrustedDate, @undo)", parameters);

            booksLoad();
        }

        int getEntrustId()
        {
            foreach (DataRow row in IDataBase.DataToDataTable("select * from entrusted where readerId = @id and durum = 0 and aktif = 1", new SqlParameter("@id", SqlDbType.Int) { Value = readerId }).Rows)
            {
                return Convert.ToInt32(row["bookId"]);
            }
            return 0;

        }

        void TakeBack()
        {
            if (bookId == 0 || readerId == 0)
            {
                MessageBox.Show("You did not choose a book or a reader!");
                return;
            }

            if (getEntrustId() == 0)
            {
                MessageBox.Show("The selected reader has no escrow!");
                return;
            }


            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@bookId", SqlDbType.Int) { Value = bookId });
            parameters.Add(new SqlParameter("@entrustedtransactionDate", SqlDbType.Date) { Value = DateTime.Now });

            IDataBase.executeNonQuery(
                "update books set durum = 1 where id = @bookId " +
                "update entrusted set entrustedtransactionDate = @entrustedtransactionDate, durum = 1 where bookId = @bookId", parameters);

            getReaderProfile();
            booksLoad();
        }



        private void txtFilterReader_TextChanged(object sender, EventArgs e)
        {
            readersLoad();
        }

        private void txtFilterBook_TextChanged(object sender, EventArgs e)
        {
            booksLoad();
        }

        private void dgReader_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                readerId = Convert.ToInt32(dgReader.Rows[e.RowIndex].Cells["id"].Value);
                getReaderProfile();
            }
        }

        private void dgBook_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                bookId = Convert.ToInt32(dgBook.Rows[e.RowIndex].Cells["id"].Value);
                getBookProfile();
            }

        }

        private void btnEntrust_Click(object sender, EventArgs e)
        {
            Entrust();
        }

        private void btnTakeBack_Click(object sender, EventArgs e)
        {

            {
                

                {
                    TakeBack();
                }
            }

        }
    }
}

     


       
                
           
           




