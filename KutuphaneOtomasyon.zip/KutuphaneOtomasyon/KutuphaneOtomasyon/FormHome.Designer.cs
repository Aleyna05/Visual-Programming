﻿
namespace KutuphaneOtomasyon
{
    partial class FormHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormHome));
            this.tabEmanetKitaplar = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgEntrustBook = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgAvailableBook = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgReaders = new System.Windows.Forms.DataGridView();
            this.btnAyarlar = new System.Windows.Forms.Button();
            this.btnOkuyucuEkle = new System.Windows.Forms.Button();
            this.btnKitapEkle = new System.Windows.Forms.Button();
            this.btnEmanetIslemleri = new System.Windows.Forms.Button();
            this.tabEmanetKitaplar.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgEntrustBook)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAvailableBook)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgReaders)).BeginInit();
            this.SuspendLayout();
            // 
            // tabEmanetKitaplar
            // 
            this.tabEmanetKitaplar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabEmanetKitaplar.Controls.Add(this.tabPage1);
            this.tabEmanetKitaplar.Controls.Add(this.tabPage2);
            this.tabEmanetKitaplar.Controls.Add(this.tabPage3);
            this.tabEmanetKitaplar.Location = new System.Drawing.Point(27, 111);
            this.tabEmanetKitaplar.Name = "tabEmanetKitaplar";
            this.tabEmanetKitaplar.SelectedIndex = 0;
            this.tabEmanetKitaplar.Size = new System.Drawing.Size(761, 327);
            this.tabEmanetKitaplar.TabIndex = 7;
            this.tabEmanetKitaplar.Tag = "";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgEntrustBook);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(753, 301);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Entrusted Books";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgEntrustBook
            // 
            this.dgEntrustBook.AllowUserToAddRows = false;
            this.dgEntrustBook.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgEntrustBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgEntrustBook.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgEntrustBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgEntrustBook.Location = new System.Drawing.Point(6, 6);
            this.dgEntrustBook.Name = "dgEntrustBook";
            this.dgEntrustBook.ReadOnly = true;
            this.dgEntrustBook.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgEntrustBook.Size = new System.Drawing.Size(741, 289);
            this.dgEntrustBook.TabIndex = 0;
            this.dgEntrustBook.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtEmanetKitaplar_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgAvailableBook);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(753, 301);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Available Books";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgAvailableBook
            // 
            this.dgAvailableBook.AllowUserToAddRows = false;
            this.dgAvailableBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgAvailableBook.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgAvailableBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAvailableBook.Location = new System.Drawing.Point(6, 6);
            this.dgAvailableBook.Name = "dgAvailableBook";
            this.dgAvailableBook.ReadOnly = true;
            this.dgAvailableBook.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgAvailableBook.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgAvailableBook.Size = new System.Drawing.Size(741, 289);
            this.dgAvailableBook.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgReaders);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(753, 301);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Readers";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgReaders
            // 
            this.dgReaders.AllowUserToAddRows = false;
            this.dgReaders.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgReaders.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgReaders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgReaders.Location = new System.Drawing.Point(6, 6);
            this.dgReaders.MultiSelect = false;
            this.dgReaders.Name = "dgReaders";
            this.dgReaders.ReadOnly = true;
            this.dgReaders.RowHeadersVisible = false;
            this.dgReaders.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgReaders.Size = new System.Drawing.Size(741, 289);
            this.dgReaders.TabIndex = 0;
            // 
            // btnAyarlar
            // 
            this.btnAyarlar.Image = ((System.Drawing.Image)(resources.GetObject("btnAyarlar.Image")));
            this.btnAyarlar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAyarlar.Location = new System.Drawing.Point(345, 30);
            this.btnAyarlar.Name = "btnAyarlar";
            this.btnAyarlar.Size = new System.Drawing.Size(100, 75);
            this.btnAyarlar.TabIndex = 4;
            this.btnAyarlar.Text = "Settings";
            this.btnAyarlar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnAyarlar.UseVisualStyleBackColor = true;
            this.btnAyarlar.Click += new System.EventHandler(this.btnAyarlar_Click);
            // 
            // btnOkuyucuEkle
            // 
            this.btnOkuyucuEkle.Image = ((System.Drawing.Image)(resources.GetObject("btnOkuyucuEkle.Image")));
            this.btnOkuyucuEkle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnOkuyucuEkle.Location = new System.Drawing.Point(239, 30);
            this.btnOkuyucuEkle.Name = "btnOkuyucuEkle";
            this.btnOkuyucuEkle.Size = new System.Drawing.Size(100, 75);
            this.btnOkuyucuEkle.TabIndex = 2;
            this.btnOkuyucuEkle.Text = "Add Reader";
            this.btnOkuyucuEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnOkuyucuEkle.UseVisualStyleBackColor = true;
            this.btnOkuyucuEkle.Click += new System.EventHandler(this.btnOkuyucuEkle_Click);
            // 
            // btnKitapEkle
            // 
            this.btnKitapEkle.Image = ((System.Drawing.Image)(resources.GetObject("btnKitapEkle.Image")));
            this.btnKitapEkle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnKitapEkle.Location = new System.Drawing.Point(133, 30);
            this.btnKitapEkle.Name = "btnKitapEkle";
            this.btnKitapEkle.Size = new System.Drawing.Size(100, 75);
            this.btnKitapEkle.TabIndex = 1;
            this.btnKitapEkle.Text = "AddBook";
            this.btnKitapEkle.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnKitapEkle.UseVisualStyleBackColor = true;
            this.btnKitapEkle.Click += new System.EventHandler(this.btnKitapEkle_Click);
            // 
            // btnEmanetIslemleri
            // 
            this.btnEmanetIslemleri.Image = ((System.Drawing.Image)(resources.GetObject("btnEmanetIslemleri.Image")));
            this.btnEmanetIslemleri.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnEmanetIslemleri.Location = new System.Drawing.Point(27, 30);
            this.btnEmanetIslemleri.Name = "btnEmanetIslemleri";
            this.btnEmanetIslemleri.Size = new System.Drawing.Size(100, 75);
            this.btnEmanetIslemleri.TabIndex = 0;
            this.btnEmanetIslemleri.Text = "Escrow Transactions";
            this.btnEmanetIslemleri.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnEmanetIslemleri.UseVisualStyleBackColor = true;
            this.btnEmanetIslemleri.Click += new System.EventHandler(this.btnEmanetIslemleri_Click);
            // 
            // FormHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabEmanetKitaplar);
            this.Controls.Add(this.btnAyarlar);
            this.Controls.Add(this.btnOkuyucuEkle);
            this.Controls.Add(this.btnKitapEkle);
            this.Controls.Add(this.btnEmanetIslemleri);
            this.Name = "FormHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormHome";
            this.Load += new System.EventHandler(this.FormHome_Load);
            this.tabEmanetKitaplar.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgEntrustBook)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgAvailableBook)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgReaders)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEmanetIslemleri;
        private System.Windows.Forms.Button btnKitapEkle;
        private System.Windows.Forms.Button btnOkuyucuEkle;
        private System.Windows.Forms.Button btnAyarlar;
        private System.Windows.Forms.TabControl tabEmanetKitaplar;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgEntrustBook;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dgAvailableBook;
        private System.Windows.Forms.DataGridView dgReaders;
    }
}