﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class FormAddReader : Form
    {
        public FormAddReader()
        {
            InitializeComponent();
        }
        int readerId = 0;
        string readerPhoto = "";


        private void FormAddReader_Load(object sender, EventArgs e)
        {
            readersLoad();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {


        }
        void PhotoSave()
        {

        }
        void AddReader()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@name", SqlDbType.VarChar) { Value = txtname.Text });
            parameters.Add(new SqlParameter("@surname", SqlDbType.VarChar) { Value = txtsurname.Text });
            string gender = "";
            if (radiobtnman.Checked)
            {
                gender = radiobtnman.Text;
            }
            else if (radiobtnwoman.Checked)
            {
                gender = radiobtnwoman.Text;
            }
            parameters.Add(new SqlParameter("@gender", SqlDbType.VarChar) { Value = gender });
            parameters.Add(new SqlParameter("@class", SqlDbType.VarChar) { Value = txtClass.Text });
            parameters.Add(new SqlParameter("@schoolnumber", SqlDbType.VarChar) { Value = txtSchoolNumber.Text });
            parameters.Add(new SqlParameter("@phonenumber", SqlDbType.VarChar) { Value = maskedtxtPhoneNumber.Text });
            parameters.Add(new SqlParameter("@adress", SqlDbType.VarChar) { Value = txtAdress.Text });

            object value = IDataBase.executeScalar("insert into readers (name, surname, gender, class, schoolnumber, phonenumber, adress) values (@name, @surname, @gender, @class, @schoolnumber, @phonenumber, @adress) select @@IDENTITY", parameters);
            readerId = Convert.ToInt32(value);

            photoSave();
            readersLoad();



            MessageBox.Show("Readers added successfully!");
        }

        void readerUpdate()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@name", SqlDbType.VarChar) { Value = txtname.Text });
            parameters.Add(new SqlParameter("@surname", SqlDbType.VarChar) { Value = txtsurname.Text });
            string gender = "";
            if (radiobtnman.Checked)
            {
                gender = radiobtnman.Text;
            }
            else if (radiobtnwoman.Checked)
            {
                gender = radiobtnwoman.Text;
            }
            parameters.Add(new SqlParameter("@gender", SqlDbType.VarChar) { Value = gender });
            parameters.Add(new SqlParameter("@class", SqlDbType.VarChar) { Value = txtClass.Text });
            parameters.Add(new SqlParameter("@schoolnumber", SqlDbType.VarChar) { Value = txtSchoolNumber.Text });
            parameters.Add(new SqlParameter("@phonenumber", SqlDbType.VarChar) { Value = maskedtxtPhoneNumber.Text });
            parameters.Add(new SqlParameter("@adress", SqlDbType.VarChar) { Value = txtAdress.Text });
            parameters.Add(new SqlParameter("@id", SqlDbType.Int) { Value = readerId });

            IDataBase.executeNonQuery("update readers set name  = @name, surname = @surname, gender = @gender, class = @class, schoolnumber= @schoolnumber, phonenumber = @phonenumber, adress = @adress where id = @id", parameters);
            photoSave();

            readersLoad();
            MessageBox.Show("Reader update is succcesful!");
        }


        void readerDelete()
        {
            IDataBase.executeNonQuery("update readers set aktif = 0 where id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = readerId });
            clean();
            readersLoad();
        }
        void readersLoad()
        {
            dg.DataSource = IDataBase.DataToDataTable("select * from readers where aktif = 1 and name+' '+surname like @search",
                    new SqlParameter("@search", SqlDbType.VarChar) { Value = string.Format("%{0}%", txtFilter.Text) });
            dg.Columns["id"].Visible = false;
        }

        void photoSave()
        {
            if (!string.IsNullOrEmpty(readerPhoto))
            {
                File.Copy(readerPhoto, Application.StartupPath + "/profile/" + readerId + ".jpg", true);
            }
        }

        void clean()
        {
            readerId = 0;
            readerPhoto = "";

            profilePicture.ImageLocation = Helper.profilePath(0);
            radiobtnman.Checked = false;
            radiobtnwoman.Checked = false;

            foreach (var item in tableLayoutPanel.Controls)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).Text = "";
                }

                if (item is MaskedTextBox)
                {
                    ((MaskedTextBox)item).Text = "";
                }
            }
        }





    


    private void btnSave_Click(object sender, EventArgs e)
        {
            if (readerId > 0)
            {
                readerUpdate();

            }
            else
            {
                AddReader();
            }
        }

        private void btnChoosePhoto_Click(object sender, EventArgs e)
        {
            openFileDialog.Filter = "(*jpg)|*.jpg";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {

                readerPhoto = openFileDialog.FileName;
                profilePicture.ImageLocation = readerPhoto;
            }



        }

        private void dg_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                readerId = Convert.ToInt32(dg.Rows[e.RowIndex].Cells["id"].Value);

                profilePicture.ImageLocation = Helper.profilePath(readerId);

                radiobtnman.Checked = false;
                radiobtnwoman.Checked = true;

                foreach (DataRow row in IDataBase.DataToDataTable("select * from readers where aktif = 1 and id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = readerId }).Rows)
                {
                    txtname.Text = row["name"].ToString();
                    txtsurname.Text = row["surname"].ToString();
                    string cinsiyet = row["gender"].ToString();
                    if (cinsiyet == radiobtnman.Text)
                    {
                        radiobtnman.Checked = true;
                    }
                    else if (cinsiyet == radiobtnwoman.Text)
                    {
                        radiobtnwoman.Checked = true;
                    }
                    txtClass.Text = row["class"].ToString();
                    txtSchoolNumber.Text = row["schoolnumber"].ToString();
                    maskedtxtPhoneNumber.Text = row["phonenumber"].ToString();
                    txtAdress.Text = row["adress"].ToString();
                }

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (readerId > 0)
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete the selected reader?", "Delete reader", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    readerDelete();

                }
                else
                {
                    MessageBox.Show("Transaction canceled!");
                }
            }
            else
            {
                MessageBox.Show("Select reader!");

            }

            }

        private void btnClean_Click(object sender, EventArgs e)
        {
            clean();
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            readersLoad();
        }
    }
    }

 


        
   

