﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class FormAddBook : Form
    {
        public FormAddBook()
        {
            InitializeComponent();
        }

        int bookId = 0;

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void FormAddBook_Load(object sender, EventArgs e)
        {
            comboBoxFill();
            booksLoad();

        }
        void comboBoxFill()
        {
            foreach (DataRow row in IDataBase.DataToDataTable("select * from cupboards").Rows)

                cbCupboard.Items.Add(row["name"].ToString());

            foreach (DataRow row in IDataBase.DataToDataTable("select * from publisher").Rows)

                cbPublisher.Items.Add(row["name"].ToString());

            foreach (DataRow row in IDataBase.DataToDataTable("select * from type").Rows)

                cbType.Items.Add(row["name"].ToString());


        }



        void booksLoad()
        {
            dg.DataSource = IDataBase.DataToDataTable("select * from books where aktif = 1 and author + ' ' + bookname like @search",
                    new SqlParameter("@search", SqlDbType.VarChar) { Value = string.Format("%{0}%", textFilter.Text) }); 
            dg.Columns["id"].Visible = false;
        }

        int getRegistrationNumber()
        {
            foreach (DataRow row in IDataBase.DataToDataTable("select ISNULL(MAX(RegistrationNumber), 0) + 1 from books where aktif = 1").Rows)
            {
                return Convert.ToInt32(row[0]);
            }
            return 1;


        }

        void addBook()
        {
            int RegistrationNumber = getRegistrationNumber();

            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@registrationnumber", SqlDbType.Int) { Value = RegistrationNumber });
            parameters.Add(new SqlParameter("bookname", SqlDbType.VarChar) { Value = txtBookName.Text });
            parameters.Add(new SqlParameter("@author", SqlDbType.VarChar) { Value = cbAuthor.Text });
            parameters.Add(new SqlParameter("@publisher", SqlDbType.VarChar) { Value = cbPublisher.Text });
            parameters.Add(new SqlParameter("@printingofyear", SqlDbType.VarChar) { Value = txtYearofPrinting.Text });
            parameters.Add(new SqlParameter("@sayfaSayisi", SqlDbType.VarChar) { Value = txtNumberofPage.Text });
            parameters.Add(new SqlParameter("@type", SqlDbType.VarChar) { Value = cbType.Text });
            parameters.Add(new SqlParameter("@explanation", SqlDbType.VarChar) { Value = txtExplanation.Text });
            parameters.Add(new SqlParameter("@cupboard", SqlDbType.VarChar) { Value = cbCupboard.Text });
            parameters.Add(new SqlParameter("@shelf", SqlDbType.VarChar) { Value = txtShelf.Text });
            parameters.Add(new SqlParameter("@sequence", SqlDbType.VarChar) { Value = txtSequence.Text });

            IDataBase.executeNonQuery("insert into books (registrationnumber, bookname, author, publisher, printingofyear, sayfaSayisi, type, explanation, cupboard, shelf, sequence) values (@registrationnumber, @bookname, @author, @publisher, @printingofyear, @sayfaSayisi, @type, @explanation, @cupboard, @shelf, @sequence)", parameters);

            txtRegistrationNumber.Text = RegistrationNumber.ToString();
            booksLoad();

         

        MessageBox.Show("Adding books is successful!");
        }


        void bookUpdate()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@bookname", SqlDbType.VarChar) { Value = txtBookName.Text });
            parameters.Add(new SqlParameter("@author", SqlDbType.VarChar) { Value = cbAuthor.Text });
            parameters.Add(new SqlParameter("@publisher", SqlDbType.VarChar) { Value = cbPublisher.Text });
            parameters.Add(new SqlParameter("@printingofyear", SqlDbType.VarChar) { Value = txtYearofPrinting.Text });
            parameters.Add(new SqlParameter("@sayfaSayisi", SqlDbType.VarChar) { Value = txtNumberofPage.Text });
            parameters.Add(new SqlParameter("@type", SqlDbType.VarChar) { Value = cbType.Text });
            parameters.Add(new SqlParameter("@explanation", SqlDbType.VarChar) { Value = txtExplanation.Text });
            parameters.Add(new SqlParameter("@cupboard", SqlDbType.VarChar) { Value = cbCupboard.Text });
            parameters.Add(new SqlParameter("@shelf", SqlDbType.VarChar) { Value = txtShelf.Text });
            parameters.Add(new SqlParameter("@sequence", SqlDbType.VarChar) { Value = txtSequence.Text });
            parameters.Add(new SqlParameter("@id", SqlDbType.Int) { Value = bookId });

            IDataBase.executeNonQuery("update books set bookname = @bookname, author = @author, printingofyear = @printingofyear, sayfaSayisi = @sayfaSayisi, type = @type, explanation = @explanation, cupboard = @cupboard, shelf = @shelf, sequence = @sequence where id = @id", parameters);


            booksLoad();

            MessageBox.Show("Book update successful!");

        }

        void bookDelete()
        {
            IDataBase.executeNonQuery("update books set aktif = 0 where id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = bookId });
            booksLoad();

            MessageBox.Show("Book deletion succesful!");
        }
        void Clean()
        {

            bookId = 0;

            foreach (var item in tableLayoutPanel.Controls)
            {
                if (item is TextBox)
                {
                    ((TextBox)item).Text = "";
                }

                if (item is ComboBox)
                {
                    ((ComboBox)item).Text = "";
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        

            if (bookId > 0)
            {
                bookUpdate();
            }
            else
            {
                addBook();
            }
        }

        private void dg_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex > -1)
            {
                bookId = Convert.ToInt32(dg.Rows[e.RowIndex].Cells["id"].Value);

                foreach (DataRow row in IDataBase.DataToDataTable("select * from books where aktif = 1 and id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = bookId }).Rows)
                {
                    txtRegistrationNumber.Text = row["registrationnumber"].ToString();
                    txtBookName.Text = row["bookname"].ToString();
                    cbAuthor.Text = row["author"].ToString();
                    cbPublisher.Text = row["publisher"].ToString();
                    txtYearofPrinting.Text = row["printingofyear"].ToString();
                    txtNumberofPage.Text = row["sayfaSayisi"].ToString();
                    cbType.Text = row["type"].ToString();
                    txtExplanation.Text = row["explanation"].ToString();
                    cbCupboard.Text = row["cupboard"].ToString();
                    txtShelf.Text = row["shelf"].ToString();
                    txtSequence.Text = row["sequence"].ToString();

                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (bookId > 0)
            {
                DialogResult dialogResult = MessageBox.Show(
                    "Are you sure you want to delete the selected book?", "Delete Book", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    bookDelete();
                    Clean();


                }
                else
                {
                    MessageBox.Show("The transaction has been canceled!");
                }
            }
            else
            {
                MessageBox.Show("Choose a book!");
            }
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            Clean();
        }

        private void textFilter_TextChanged(object sender, EventArgs e)
        {
            booksLoad();
        }
    }
}



    


    


