﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click_2(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void buttonregister_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txtname.Text) ||
              string.IsNullOrEmpty(txtsurname.Text) ||
              string.IsNullOrEmpty(txtusername.Text) ||
              string.IsNullOrEmpty(txtpassword.Text) ||
              string.IsNullOrEmpty(txtrpassword.Text))

            {

                MessageBox.Show("Fill in all fields!");
                return;

            }
            if (txtpassword.Text != txtrpassword.Text)
            {
                MessageBox.Show("The passwords you entered do not match!");
                return;


            }
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@name", SqlDbType.VarChar) { Value = txtname.Text });
            parameters.Add(new SqlParameter("@surname", SqlDbType.VarChar) { Value = txtsurname.Text });
            parameters.Add(new SqlParameter("@username", SqlDbType.VarChar) { Value = txtusername.Text });
            parameters.Add(new SqlParameter("@password", SqlDbType.VarChar) { Value = txtpassword.Text });
            IDataBase.executeNonQuery("insert into kullanicilar (name , surname , username , password)  value (@name , @surname , @userame , @password )", parameters);

            LoginForm formLogin = new LoginForm();
            formLogin.Show();

            this.Hide();
            
        }

     
        

        }
    }


