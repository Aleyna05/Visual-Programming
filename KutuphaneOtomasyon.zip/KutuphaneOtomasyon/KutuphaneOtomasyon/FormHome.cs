﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class FormHome : Form
    {
        public FormHome()
        {
            InitializeComponent();
        }

        void dataGridViewLoad()
        {
            dgEntrustBook.DataSource = IDataBase.DataToDataTable("select registrationnumber as [Registration Number], bookname as [Book Name],  author as [Author], publisher as [Publisher], printingofyear as [Year of Printing], sayfaSayisi as [Number of Page], type as [Type] from books where aktif = 1 and durum = 0");
            dgAvailableBook.DataSource = IDataBase.DataToDataTable("select registrationnumber as [Registration Number], bookname as [Book Name], author as [Author], publisher as [Publisher], printingofyear as [Year of Printing], sayfaSayisi as [Number of Page], type as [Type] from books where aktif = 1 and durum = 1");
            dgReaders.DataSource = IDataBase.DataToDataTable("select name as [name], surname as [Surname], gender as [Gender], class as [Class], schoolnumber as [School Number], phonenumber as [Phone Number ], adress as [Adress]  from readers where aktif = 1");

        }
        
        private void btnEmanetIslemleri_Click(object sender, EventArgs e)
        {
            FormEntrusted formEntrusted = new FormEntrusted();
            formEntrusted.Show();


        }

        private void btnKitapEkle_Click(object sender, EventArgs e)
        {
           FormAddBook formAddBook = new FormAddBook();
           formAddBook.Show();
        }

        private void btnOkuyucuEkle_Click(object sender, EventArgs e)
        {
            FormAddReader formAddReader = new FormAddReader();
            formAddReader.Show();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void dtEmanetKitaplar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnAyarlar_Click(object sender, EventArgs e)
        {
            FormEdit formEdit = new FormEdit();
            formEdit.Show();

        }

        private void FormHome_Load(object sender, EventArgs e)
        {
            dataGridViewLoad();
        }

        private void FormHome_Activated(object sender , EventArgs e)
        {
            dataGridViewLoad();
        }

        
    }
}
