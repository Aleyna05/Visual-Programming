﻿using KutuphaneOtomasyon.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon
{
    public partial class FormEdit : Form
    {
        public FormEdit()
        {
            InitializeComponent();
        }
        int rowId = 0;
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void FormEdit_Load(object sender, EventArgs e)
        {

        }



        string getTableName()
        {
            switch (cbbTableName.SelectedIndex)
            {
                case 0:
                    return "authors";

                case 1:
                    return "publisher";

                case 2:
                    return "type";

                case 3:
                    return "cupboards";

                default:
                    return "";
            }
        }

        void tableLoad()
        {

            if (!string.IsNullOrEmpty(getTableName()))
            {
                dg.DataSource = IDataBase.DataToDataTable("select * from " + getTableName());
                dg.Columns["id"].Visible = false;
            }
        }


        void Add()
        {
            IDataBase.executeNonQuery("insert into " + getTableName() + " (name) values (@name)", new SqlParameter("@name", SqlDbType.VarChar) { Value = txtName.Text });
            tableLoad();
            MessageBox.Show("Transaction Add Succesful!");
        }

        void update()
        {
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@name", SqlDbType.VarChar) { Value = txtName.Text });
            parameters.Add(new SqlParameter("@id", SqlDbType.Int) { Value = rowId });
            IDataBase.executeNonQuery("update " + getTableName() + " set name = @name where id = @id", parameters);

            tableLoad();
            MessageBox.Show("Update  succesful!");
        }

        void delete()
        {
            IDataBase.executeNonQuery("delete " + getTableName() + " where id = @id", new SqlParameter("@id", SqlDbType.Int) { Value = rowId });
            clean();
            tableLoad();
            MessageBox.Show("Delete succesful!");

        }

        void clean()
        {
            
            {
                rowId = 0;
                txtName.Text = "";
            }
        }
        private void cbbTableName_SelectedIndexChanged(object sender, EventArgs e)
        {
            tableLoad();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(getTableName()))
            {
                MessageBox.Show("Choose a table");
                return;
            }

            if (rowId > 0)
            {
                update();
            }
            else
            {
                Add();
            }
        }

        private void dg_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                rowId = Convert.ToInt32(dg.Rows[e.RowIndex].Cells["id"].Value);
                txtName.Text = dg.Rows[e.RowIndex].Cells["name"].Value.ToString();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (rowId > 0)
            {
                DialogResult dialogResult = MessageBox.Show(
                    "Are you sure you want to delete the selected row?", "Delete  Line", MessageBoxButtons.YesNo);

                if (dialogResult == DialogResult.Yes)
                {
                    delete();
                }
            }
            else
            {
                MessageBox.Show("Select Line!");
            }
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            clean();
        }
    }
    }

    
    






