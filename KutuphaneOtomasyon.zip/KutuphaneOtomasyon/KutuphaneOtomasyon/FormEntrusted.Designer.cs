﻿
namespace KutuphaneOtomasyon
{
    partial class FormEntrusted
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEntrusted));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblFilterReader = new System.Windows.Forms.Label();
            this.txtFilterReader = new System.Windows.Forms.TextBox();
            this.dgReader = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNameSurname = new System.Windows.Forms.Label();
            this.lblClass = new System.Windows.Forms.Label();
            this.lblSchoolNumber = new System.Windows.Forms.Label();
            this.lblPriceofDelay = new System.Windows.Forms.Label();
            this.pictureProfile = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnEntrust = new System.Windows.Forms.Button();
            this.btnTakeBack = new System.Windows.Forms.Button();
            this.lblFİlterBook = new System.Windows.Forms.Label();
            this.txtFilterBook = new System.Windows.Forms.TextBox();
            this.dgBook = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblRegistrationNumber = new System.Windows.Forms.Label();
            this.lblBookName = new System.Windows.Forms.Label();
            this.lblAuthor = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgReader)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureProfile)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgBook)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lblFilterReader);
            this.groupBox1.Controls.Add(this.txtFilterReader);
            this.groupBox1.Controls.Add(this.dgReader);
            this.groupBox1.Controls.Add(this.tableLayoutPanel1);
            this.groupBox1.Location = new System.Drawing.Point(14, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(795, 200);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose Reader";
            // 
            // lblFilterReader
            // 
            this.lblFilterReader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFilterReader.AutoSize = true;
            this.lblFilterReader.Location = new System.Drawing.Point(573, 138);
            this.lblFilterReader.Name = "lblFilterReader";
            this.lblFilterReader.Size = new System.Drawing.Size(32, 13);
            this.lblFilterReader.TabIndex = 3;
            this.lblFilterReader.Text = "Filter:";
            // 
            // txtFilterReader
            // 
            this.txtFilterReader.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFilterReader.Location = new System.Drawing.Point(611, 135);
            this.txtFilterReader.Name = "txtFilterReader";
            this.txtFilterReader.Size = new System.Drawing.Size(150, 20);
            this.txtFilterReader.TabIndex = 2;
            this.txtFilterReader.TextChanged += new System.EventHandler(this.txtFilterReader_TextChanged);
            // 
            // dgReader
            // 
            this.dgReader.AllowUserToAddRows = false;
            this.dgReader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgReader.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgReader.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgReader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgReader.Location = new System.Drawing.Point(262, 19);
            this.dgReader.MultiSelect = false;
            this.dgReader.Name = "dgReader";
            this.dgReader.ReadOnly = true;
            this.dgReader.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgReader.Size = new System.Drawing.Size(499, 110);
            this.dgReader.TabIndex = 1;
            this.dgReader.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgReader_CellClick);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureProfile, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 19);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(250, 110);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.lblNameSurname, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblClass, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblSchoolNumber, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblPriceofDelay, 0, 3);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(83, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(164, 104);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // lblNameSurname
            // 
            this.lblNameSurname.AutoSize = true;
            this.lblNameSurname.Location = new System.Drawing.Point(3, 0);
            this.lblNameSurname.Name = "lblNameSurname";
            this.lblNameSurname.Size = new System.Drawing.Size(83, 13);
            this.lblNameSurname.TabIndex = 0;
            this.lblNameSurname.Text = "Name Surname:";
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Location = new System.Drawing.Point(3, 26);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(35, 13);
            this.lblClass.TabIndex = 1;
            this.lblClass.Text = "Class:";
            // 
            // lblSchoolNumber
            // 
            this.lblSchoolNumber.AutoSize = true;
            this.lblSchoolNumber.Location = new System.Drawing.Point(3, 52);
            this.lblSchoolNumber.Name = "lblSchoolNumber";
            this.lblSchoolNumber.Size = new System.Drawing.Size(83, 13);
            this.lblSchoolNumber.TabIndex = 2;
            this.lblSchoolNumber.Text = "School Number:";
            // 
            // lblPriceofDelay
            // 
            this.lblPriceofDelay.AutoSize = true;
            this.lblPriceofDelay.Location = new System.Drawing.Point(3, 78);
            this.lblPriceofDelay.Name = "lblPriceofDelay";
            this.lblPriceofDelay.Size = new System.Drawing.Size(76, 13);
            this.lblPriceofDelay.TabIndex = 3;
            this.lblPriceofDelay.Text = "Price of Delay:";
            // 
            // pictureProfile
            // 
            this.pictureProfile.Image = ((System.Drawing.Image)(resources.GetObject("pictureProfile.Image")));
            this.pictureProfile.Location = new System.Drawing.Point(3, 3);
            this.pictureProfile.Name = "pictureProfile";
            this.pictureProfile.Size = new System.Drawing.Size(74, 100);
            this.pictureProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureProfile.TabIndex = 1;
            this.pictureProfile.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox2.Controls.Add(this.tableLayoutPanel4);
            this.groupBox2.Controls.Add(this.lblFİlterBook);
            this.groupBox2.Controls.Add(this.txtFilterBook);
            this.groupBox2.Controls.Add(this.dgBook);
            this.groupBox2.Controls.Add(this.tableLayoutPanel3);
            this.groupBox2.Location = new System.Drawing.Point(20, 235);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(789, 200);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Choose Book";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.btnEntrust, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.btnTakeBack, 0, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(532, 163);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(229, 30);
            this.tableLayoutPanel4.TabIndex = 4;
            // 
            // btnEntrust
            // 
            this.btnEntrust.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnEntrust.Location = new System.Drawing.Point(117, 3);
            this.btnEntrust.Name = "btnEntrust";
            this.btnEntrust.Size = new System.Drawing.Size(109, 24);
            this.btnEntrust.TabIndex = 0;
            this.btnEntrust.Text = "Entrust";
            this.btnEntrust.UseVisualStyleBackColor = true;
            this.btnEntrust.Click += new System.EventHandler(this.btnEntrust_Click);
            // 
            // btnTakeBack
            // 
            this.btnTakeBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTakeBack.Location = new System.Drawing.Point(3, 3);
            this.btnTakeBack.Name = "btnTakeBack";
            this.btnTakeBack.Size = new System.Drawing.Size(108, 24);
            this.btnTakeBack.TabIndex = 1;
            this.btnTakeBack.Text = "Take Back";
            this.btnTakeBack.UseVisualStyleBackColor = true;
            this.btnTakeBack.Click += new System.EventHandler(this.btnTakeBack_Click);
            // 
            // lblFİlterBook
            // 
            this.lblFİlterBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFİlterBook.AutoSize = true;
            this.lblFİlterBook.Location = new System.Drawing.Point(573, 140);
            this.lblFİlterBook.Name = "lblFİlterBook";
            this.lblFİlterBook.Size = new System.Drawing.Size(32, 13);
            this.lblFİlterBook.TabIndex = 6;
            this.lblFİlterBook.Text = "Filter:";
            // 
            // txtFilterBook
            // 
            this.txtFilterBook.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFilterBook.Location = new System.Drawing.Point(611, 137);
            this.txtFilterBook.Name = "txtFilterBook";
            this.txtFilterBook.Size = new System.Drawing.Size(150, 20);
            this.txtFilterBook.TabIndex = 5;
            this.txtFilterBook.TextChanged += new System.EventHandler(this.txtFilterBook_TextChanged);
            // 
            // dgBook
            // 
            this.dgBook.AllowUserToAddRows = false;
            this.dgBook.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgBook.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgBook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgBook.Location = new System.Drawing.Point(262, 19);
            this.dgBook.MultiSelect = false;
            this.dgBook.Name = "dgBook";
            this.dgBook.ReadOnly = true;
            this.dgBook.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgBook.Size = new System.Drawing.Size(499, 110);
            this.dgBook.TabIndex = 4;
            this.dgBook.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgBook_CellClick);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblRegistrationNumber, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblBookName, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblAuthor, 1, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(6, 19);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(250, 110);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "Registration Number:";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Book Name:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Author";
            // 
            // lblRegistrationNumber
            // 
            this.lblRegistrationNumber.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblRegistrationNumber.AutoSize = true;
            this.lblRegistrationNumber.Location = new System.Drawing.Point(83, 11);
            this.lblRegistrationNumber.Name = "lblRegistrationNumber";
            this.lblRegistrationNumber.Size = new System.Drawing.Size(13, 13);
            this.lblRegistrationNumber.TabIndex = 3;
            this.lblRegistrationNumber.Text = "..";
            // 
            // lblBookName
            // 
            this.lblBookName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblBookName.AutoSize = true;
            this.lblBookName.Location = new System.Drawing.Point(83, 47);
            this.lblBookName.Name = "lblBookName";
            this.lblBookName.Size = new System.Drawing.Size(13, 13);
            this.lblBookName.TabIndex = 4;
            this.lblBookName.Text = "..";
            // 
            // lblAuthor
            // 
            this.lblAuthor.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblAuthor.AutoSize = true;
            this.lblAuthor.Location = new System.Drawing.Point(83, 84);
            this.lblAuthor.Name = "lblAuthor";
            this.lblAuthor.Size = new System.Drawing.Size(13, 13);
            this.lblAuthor.TabIndex = 5;
            this.lblAuthor.Text = "..";
            // 
            // FormEntrusted
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 461);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormEntrusted";
            this.Text = "Escrow Transaction";
            this.Load += new System.EventHandler(this.FormEntrusted_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgReader)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureProfile)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgBook)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.PictureBox pictureProfile;
        private System.Windows.Forms.Label lblFilterReader;
        private System.Windows.Forms.TextBox txtFilterReader;
        private System.Windows.Forms.DataGridView dgReader;
        private System.Windows.Forms.Label lblNameSurname;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label lblSchoolNumber;
        private System.Windows.Forms.Label lblPriceofDelay;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblRegistrationNumber;
        private System.Windows.Forms.Label lblBookName;
        private System.Windows.Forms.Label lblAuthor;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button btnEntrust;
        private System.Windows.Forms.Label lblFİlterBook;
        private System.Windows.Forms.TextBox txtFilterBook;
        private System.Windows.Forms.DataGridView dgBook;
        private System.Windows.Forms.Button btnTakeBack;
    }
}