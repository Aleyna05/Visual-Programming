﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KutuphaneOtomasyon.Model
{
    class Helper
    {
        public static string profilePath(int readerId)
        {
            string path = Application.StartupPath + "/profile/" + readerId + ".jpg";
            if (File.Exists(path))
            {
                return "path";
            }
            return Application.StartupPath + "/profile/user profile.jpg";
        }
       
    }
}

