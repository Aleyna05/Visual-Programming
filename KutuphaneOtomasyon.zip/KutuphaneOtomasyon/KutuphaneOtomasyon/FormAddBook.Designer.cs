﻿
namespace KutuphaneOtomasyon
{
    partial class FormAddBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAddBook));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.la = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.txtRegistrationNumber = new System.Windows.Forms.TextBox();
            this.txtBookName = new System.Windows.Forms.TextBox();
            this.txtYearofPrinting = new System.Windows.Forms.TextBox();
            this.txtNumberofPage = new System.Windows.Forms.TextBox();
            this.txtShelf = new System.Windows.Forms.TextBox();
            this.txtSequence = new System.Windows.Forms.TextBox();
            this.cbAuthor = new System.Windows.Forms.ComboBox();
            this.cbPublisher = new System.Windows.Forms.ComboBox();
            this.cbType = new System.Windows.Forms.ComboBox();
            this.cbCupboard = new System.Windows.Forms.ComboBox();
            this.txtExplanation = new System.Windows.Forms.TextBox();
            this.tableLayoutPanell = new System.Windows.Forms.TableLayoutPanel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClean = new System.Windows.Forms.Button();
            this.dg = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.textFilter = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel.SuspendLayout();
            this.tableLayoutPanell.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // la
            // 
            resources.ApplyResources(this.la, "la");
            this.la.Name = "la";
            this.la.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            this.label5.Tag = "";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // tableLayoutPanel
            // 
            resources.ApplyResources(this.tableLayoutPanel, "tableLayoutPanel");
            this.tableLayoutPanel.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.label11, 0, 10);
            this.tableLayoutPanel.Controls.Add(this.label2, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.label10, 0, 9);
            this.tableLayoutPanel.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.label9, 0, 8);
            this.tableLayoutPanel.Controls.Add(this.la, 0, 3);
            this.tableLayoutPanel.Controls.Add(this.label8, 0, 7);
            this.tableLayoutPanel.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel.Controls.Add(this.label7, 0, 6);
            this.tableLayoutPanel.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel.Controls.Add(this.txtRegistrationNumber, 1, 0);
            this.tableLayoutPanel.Controls.Add(this.txtBookName, 1, 1);
            this.tableLayoutPanel.Controls.Add(this.txtYearofPrinting, 1, 4);
            this.tableLayoutPanel.Controls.Add(this.txtNumberofPage, 1, 5);
            this.tableLayoutPanel.Controls.Add(this.txtShelf, 1, 8);
            this.tableLayoutPanel.Controls.Add(this.txtSequence, 1, 9);
            this.tableLayoutPanel.Controls.Add(this.cbAuthor, 1, 2);
            this.tableLayoutPanel.Controls.Add(this.cbPublisher, 1, 3);
            this.tableLayoutPanel.Controls.Add(this.cbType, 1, 6);
            this.tableLayoutPanel.Controls.Add(this.cbCupboard, 1, 7);
            this.tableLayoutPanel.Controls.Add(this.txtExplanation, 1, 10);
            this.tableLayoutPanel.Name = "tableLayoutPanel";
            // 
            // txtRegistrationNumber
            // 
            resources.ApplyResources(this.txtRegistrationNumber, "txtRegistrationNumber");
            this.txtRegistrationNumber.Name = "txtRegistrationNumber";
            this.txtRegistrationNumber.ReadOnly = true;
            // 
            // txtBookName
            // 
            resources.ApplyResources(this.txtBookName, "txtBookName");
            this.txtBookName.Name = "txtBookName";
            // 
            // txtYearofPrinting
            // 
            resources.ApplyResources(this.txtYearofPrinting, "txtYearofPrinting");
            this.txtYearofPrinting.Name = "txtYearofPrinting";
            // 
            // txtNumberofPage
            // 
            resources.ApplyResources(this.txtNumberofPage, "txtNumberofPage");
            this.txtNumberofPage.Name = "txtNumberofPage";
            // 
            // txtShelf
            // 
            resources.ApplyResources(this.txtShelf, "txtShelf");
            this.txtShelf.Name = "txtShelf";
            // 
            // txtSequence
            // 
            resources.ApplyResources(this.txtSequence, "txtSequence");
            this.txtSequence.Name = "txtSequence";
            // 
            // cbAuthor
            // 
            resources.ApplyResources(this.cbAuthor, "cbAuthor");
            this.cbAuthor.FormattingEnabled = true;
            this.cbAuthor.Name = "cbAuthor";
            // 
            // cbPublisher
            // 
            resources.ApplyResources(this.cbPublisher, "cbPublisher");
            this.cbPublisher.FormattingEnabled = true;
            this.cbPublisher.Name = "cbPublisher";
            // 
            // cbType
            // 
            resources.ApplyResources(this.cbType, "cbType");
            this.cbType.FormattingEnabled = true;
            this.cbType.Name = "cbType";
            // 
            // cbCupboard
            // 
            resources.ApplyResources(this.cbCupboard, "cbCupboard");
            this.cbCupboard.FormattingEnabled = true;
            this.cbCupboard.Name = "cbCupboard";
            // 
            // txtExplanation
            // 
            resources.ApplyResources(this.txtExplanation, "txtExplanation");
            this.txtExplanation.Name = "txtExplanation";
            // 
            // tableLayoutPanell
            // 
            resources.ApplyResources(this.tableLayoutPanell, "tableLayoutPanell");
            this.tableLayoutPanell.Controls.Add(this.btnSave, 0, 0);
            this.tableLayoutPanell.Controls.Add(this.btnDelete, 1, 0);
            this.tableLayoutPanell.Controls.Add(this.btnClean, 2, 0);
            this.tableLayoutPanell.Name = "tableLayoutPanell";
            // 
            // btnSave
            // 
            resources.ApplyResources(this.btnSave, "btnSave");
            this.btnSave.Name = "btnSave";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnDelete
            // 
            resources.ApplyResources(this.btnDelete, "btnDelete");
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClean
            // 
            resources.ApplyResources(this.btnClean, "btnClean");
            this.btnClean.Name = "btnClean";
            this.btnClean.UseVisualStyleBackColor = true;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // dg
            // 
            this.dg.AllowUserToAddRows = false;
            resources.ApplyResources(this.dg, "dg");
            this.dg.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg.MultiSelect = false;
            this.dg.Name = "dg";
            this.dg.ReadOnly = true;
            this.dg.RowHeadersVisible = false;
            this.dg.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dg.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dg_CellClick);
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // textFilter
            // 
            resources.ApplyResources(this.textFilter, "textFilter");
            this.textFilter.Name = "textFilter";
            this.textFilter.TextChanged += new System.EventHandler(this.textFilter_TextChanged);
            // 
            // FormAddBook
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textFilter);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.dg);
            this.Controls.Add(this.tableLayoutPanell);
            this.Controls.Add(this.tableLayoutPanel);
            this.Name = "FormAddBook";
            this.ShowIcon = false;
            this.Load += new System.EventHandler(this.FormAddBook_Load);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            this.tableLayoutPanell.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label la;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.TextBox txtRegistrationNumber;
        private System.Windows.Forms.TextBox txtBookName;
        private System.Windows.Forms.TextBox txtYearofPrinting;
        private System.Windows.Forms.TextBox txtNumberofPage;
        private System.Windows.Forms.TextBox txtShelf;
        private System.Windows.Forms.TextBox txtSequence;
        private System.Windows.Forms.ComboBox cbAuthor;
        private System.Windows.Forms.ComboBox cbPublisher;
        private System.Windows.Forms.ComboBox cbType;
        private System.Windows.Forms.ComboBox cbCupboard;
        private System.Windows.Forms.TextBox txtExplanation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanell;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.DataGridView dg;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textFilter;
    }
}